var functions = require('firebase-functions');
var admin = require('firebase-admin');

admin.initializeApp({
  credential: admin.credential.cert({
    "type": "service_account",
    "project_id": "happy-feet",
    "private_key_id": "",
    "private_key": "",
    "client_email": "",
    "client_id": "",
    "auth_uri": "",
    "token_uri": "",
    "auth_provider_x509_cert_url": "",
    "client_x509_cert_url": ""
  }),
  databaseURL: ""
});

var accountSid = '';
var authToken = '';
var alerts = [{
  "Name": "Cecilia Ramos",
  "AlertLevel": "Red",
  "Room": "13A",
  "Floor": "Floor 1"
},

{
  "Name": "Cheryl Montes",
  "AlertLevel": "Orange",
  "Room": "22A",
  "Floor": "Floor 2"
},

{
  "Name": "Jack Frost",
  "AlertLevel": "Orange",
  "Room": "24B",
  "Floor": "Floor 2"
},

{
  "Name": "Mason River",
  "AlertLevel": "Orange",
  "Room": "8A",
  "Floor": "Floor 1"
}]; 
	
//require the Twilio module and create a REST client
var client = require('twilio')(accountSid, authToken);

exports.helloWorld = (req, res) => {
  // Example input: {"message": "Hello!"}
  var item = alerts[Math.floor(Math.random()*alerts.length)];
  
  
  admin.database().ref('/').push(item);
  
  client.messages.create({
      to: "+",
      from: "+",
      body: item.AlertLevel + " for " + item.Name + " in room " + item.Room,
  });
  
  if (req.body.message === undefined) {
    // This is an error case, as "message" is required.
    res.status(400).send('No message defined!');
  } else {
    // Everything is okay.
    console.log(req.body.message);
    res.status(200).send('Success: ' + "Hello Happy Feet!");
  }
};
